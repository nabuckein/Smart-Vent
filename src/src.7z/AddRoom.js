import React, { Component } from 'react';
import Radium from 'radium';
import {StyleRoot} from 'radium';

//var firebase = require("firebase");
  
class AddRoom extends Component {  

  /*constructor(props){ 
    super(props);   

    this.user = firebase.auth().currentUser;
    this.amountOfRooms;
    this.state = {
      amountOfRooms:0,
    }
    
  }*/


 
  render() {

    return (
      <div style={styles.StyleRootParent}>
        <StyleRoot style={styles.StyleRoot}>
          <div className="AddRoom" style={styles.AddRoom}>    
            <div className="addRoomsDiv" style={styles.addRoomDiv}>
                <p className="addRoomTitle" style={styles.addRoomTitle}>Add a room</p>
                <i className="fa fa-plus-circle" style={styles.icon} aria-hidden="true" onClick={this.props.showRoomSetup}></i>
            </div>      
          </div>
        </StyleRoot> 
      </div>
    );
  }
}

export default AddRoom;


const styles = {
  StyleRootParent:{
    width:'30%'
  },
  StyleRoot:{
    height: '100%',
    display:'flex',
    justifyContent:'center',
    
    '@media (min-width:0px) and (max-width:320px)':{      
      width:'50%'
    },
    '@media (min-width:320px) and (max-width:540px)':{      
      width:'65%'
    },
    '@media (min-width:540px) and (max-width:760px)':{
      width:'50%'
    },
    '@media (min-width:760px) and (max-width:920px)':{
      width:'75%'
    },
    '@media (min-width:920px)':{
      width:'40%'
    },
  },
  AddRoom:{
    background: 'rgb(40,175,255)',
    textAlign:'center',
    paddingBottom:25,
    border:'solid 3px transparent',
    borderRadius:5,
    width:'100%',
     
    
    ':hover':{
      border: 'solid white 3px',
    }
  },
  addRoomDiv:{
    width:'100%',
    
    textAlign: 'center', 
    marginBottom: 20,  
    
    

  },
  addRoomTitle:{
    '@media (min-width:0px) and (max-width:320px)':{
      fontSize:20
    },
    '@media (min-width:320px) and (max-width:540px)':{
      fontSize:26
    },
    '@media (min-width:540px) and (max-width:760px)':{
      fontSize:30
    },
    '@media (min-width:760px) and (max-width:920px)':{
      fontSize:28
    },
    '@media (min-width:920px)':{
      fontSize:26
    }
  },
  icon:{
    '@media (min-width:0px) and (max-width:320px)':{
      fontSize:20
    },
    '@media (min-width:320px) and (max-width:540px)':{
      fontSize:26
    },
    '@media (min-width:540px) and (max-width:760px)':{
      fontSize:30
    },
    '@media (min-width:760px) and (max-width:920px)':{
      fontSize:34
    },
    '@media (min-width:920px)':{
      fontSize:56
    }
  }

}